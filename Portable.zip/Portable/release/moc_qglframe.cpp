/****************************************************************************
** Meta object code from reading C++ file 'qglframe.h'
**
** Created: Tue Jul 15 19:05:27 2014
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../GLSLEditor/qglframe.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qglframe.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_QGLFrame[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: signature, parameters, type, tag, flags
      16,   10,    9,    9, 0x05,
      38,   10,    9,    9, 0x05,
      60,   10,    9,    9, 0x05,
     124,   82,    9,    9, 0x05,
     171,  166,    9,    9, 0x05,
     193,  189,    9,    9, 0x05,

 // slots: signature, parameters, type, tag, flags
     210,    9,    9,    9, 0x0a,
     222,    9,    9,    9, 0x0a,
     234,   10,    9,    9, 0x0a,
     252,   10,    9,    9, 0x0a,
     270,   10,    9,    9, 0x0a,
     297,  288,    9,    9, 0x0a,
     338,  324,    9,    9, 0x0a,
     375,  367,    9,    9, 0x0a,
     399,    9,    9,    9, 0x0a,
     416,    9,    9,    9, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_QGLFrame[] = {
    "QGLFrame\0\0angle\0xRotationChanged(int)\0"
    "yRotationChanged(int)\0zRotationChanged(int)\0"
    "start,end,newValueFloat,newValueInt,isInt\0"
    "sendBackValueInfo(int,int,float,int,bool)\0"
    "code\0sendCode(QString)\0FPS\0sendFPS(QString)\0"
    "prevModel()\0nextModel()\0setXRotation(int)\0"
    "setYRotation(int)\0setZRotation(int)\0"
    "glslwptr\0handleCodeChange(QObject*)\0"
    "position,mode\0getValueChanged(int,QString)\0"
    "newCode\0getCodeChanged(QString)\0"
    "openFileDialog()\0animate()\0"
};

void QGLFrame::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        QGLFrame *_t = static_cast<QGLFrame *>(_o);
        switch (_id) {
        case 0: _t->xRotationChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->yRotationChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->zRotationChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->sendBackValueInfo((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< float(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5]))); break;
        case 4: _t->sendCode((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->sendFPS((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->prevModel(); break;
        case 7: _t->nextModel(); break;
        case 8: _t->setXRotation((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 9: _t->setYRotation((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 10: _t->setZRotation((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->handleCodeChange((*reinterpret_cast< QObject*(*)>(_a[1]))); break;
        case 12: _t->getValueChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 13: _t->getCodeChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 14: _t->openFileDialog(); break;
        case 15: _t->animate(); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData QGLFrame::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject QGLFrame::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_QGLFrame,
      qt_meta_data_QGLFrame, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &QGLFrame::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *QGLFrame::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *QGLFrame::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QGLFrame))
        return static_cast<void*>(const_cast< QGLFrame*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int QGLFrame::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void QGLFrame::xRotationChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QGLFrame::yRotationChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QGLFrame::zRotationChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QGLFrame::sendBackValueInfo(int _t1, int _t2, float _t3, int _t4, bool _t5)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QGLFrame::sendCode(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QGLFrame::sendFPS(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_END_MOC_NAMESPACE
