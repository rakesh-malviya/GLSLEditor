About::
=======
Interactive editor for GLSL(shaders). Based on tool mentioned in Bret Victor's talk on Inventing on Principle

Go to release/GLSLEditor.exe to execute the GLSL Editor

Hotkeys::
=========

Ctrl + >  : Increase value of constant under the cursor

Ctrl + <  : Decrease value of constant under the cursor